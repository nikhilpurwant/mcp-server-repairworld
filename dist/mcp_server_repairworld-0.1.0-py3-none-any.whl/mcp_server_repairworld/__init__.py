# agent_with_mcp/__init__.py
# This file marks the directory as a package.